
#
# TP-Link Wi-Fi Smart Plug Protocol Client
# For use with TP-Link HS-100 or HS-110
#
# by Lubomir Stroetmann
# Copyright 2016 softScheck GmbH
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

import socket
import json
import sys
import argparse
from struct import pack
from pprint import pprint
version = 0.2

# Check if hostname is valid
def validHostname(hostname):
	try:
		socket.gethostbyname(hostname)
	except socket.error:
		parser.error("Invalid hostname.")
	return hostname

# Predefined Smart Plug Commands
# For a full list of commands, consult tplink_commands.txt

# Encryption and Decryption of TP-Link Smart Home Protocol
# XOR Autokey Cipher with starting key = 171
def encrypt(string):
	key = 171
	result = pack('>I', len(string))
	j=1
	for i in string:
		#a = key ^ ord(i)
		a = key ^ i
		key = a
		result+=bytes([a])
	return result

def decrypt(string):
	key = 171
	result = "".encode('latin-1')
	for i in string:
		a = key ^ i
		key=i
		result += bytes([a])
	return result

def do_tplink(ip,cmd,port,useJson=True):
	try:
		sock_tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		sock_tcp.settimeout(2)
		sock_tcp.connect((ip, port))
		#print("cmd: "+cmd+" ip "+ip+" port "+str(port))
		sock_tcp.send(encrypt(cmd.encode('latin-1')))
		data = sock_tcp.recv(2048)
		#print(type(data))
		#print(data)
		#print(data[4:])
		sdata="".join(chr(x) for x in decrypt(data[4:]))
		#print(sdata)
		if(useJson):
			#result = json.loads(decrypt(data[4:]))
			result = json.loads(sdata)
		else:
			#result = json.dumps(json.loads(decrypt(data[4:])),sort_keys = True, indent = 2)
			result = json.dumps(json.loads(sdata),sort_keys = True, indent = 2)
		sock_tcp.close()
		return(result)
	except socket.error:
		#quit("Cound not connect to host " + ip + ":" + str(port))
		print("Connection failure: "+ ip + ":" + str(port))
		return(False)
