import os
import glob
import time
import requests 
import sqlite3
import json
import platform
import urllib.parse
import datetime
from sqlite3 import Error
from tplib3 import *
from rpiglobals import rpiInitVariables

# resetOutDoor.py
#
# Check latest out door station update. It is more than two ours old, reset sender
#
##
# Python version: 3
#
# Modifictions
#  28/12-2020   Initial coding
# 
# Usage:
# python3 resetOutDoor
#

progVersion="1.0 28122020"



def create_connection(db_file):
	""" create a database connection to a SQLite database """
	conn = None
	try:
		conn = sqlite3.connect(db_file)
		# print(sqlite3.version)
	except Error as e:
		print(e)
	return conn
#
#  Prints output from tp link command
#
def printResult(result):
	if( u'set_relay_state' in result["system"]):
		print(" Command, Error Code: "+str(result["system"]["set_relay_state"]["err_code"]),end=' ')
	elif (u'get_sysinfo' in result["system"]):
		print(" Relay state: "+str(result["system"]["get_sysinfo"]["relay_state"]))
	else:
		print(" Unknown result ")
		print(result)
#
# Reset Outdoor
#
def resetOutDoor(rpig,deviceName):
	#
	# Allocate DB Connection
	#
	conn=create_connection(rpig.weewxfile)
	if (conn is False):
		print("Open of database: "+rpig.weewxfile+" failed ")
		return(False)
	#
	# Execute SQL
	#
	cur = conn.cursor()
	sqlstmt="select inTemp,outTemp,datetime from archive  where datetime="
	sqlstmt=sqlstmt+"(select max(datetime) from archive)"
	cur.execute(sqlstmt)
	rows = cur.fetchall()
	inTemp=((rows[0])[0]-32)/1.8
	outTemp=(rows[0])[1]
	weweexTime=(rows[0])[2]
	if( outTemp is None):
		print("No outdoor sensor recorded at: "+str(datetime.datetime.fromtimestamp(weweexTime)))
		#
		# Find device IP
		#
		fp=open(rpig.socketConfigFile)
		line=fp.readline().strip('\n')
		results=dict()
		ipAddress=None
		while (line):
			if len(line) >1:
				if(line.split(' ')[1] == deviceName):
					ipAddress=line.split(' ')[0]
					break
			line=fp.readline().strip('\n')
		fp.close()
		#
		# Check if IP adress was found
		#
		if(ipAddress is None):
			print("No Ip address found for: "+deviceName)
			return(False)
		#
		# Set device state
		#
		onsw='{"system":{"set_relay_state":{"state":1}}}'
		offsw= '{"system":{"set_relay_state":{"state":0}}}'
		info='{"system":{"get_sysinfo":{}}}'
		print("Resetting device: "+deviceName+" IP: "+ipAddress)
		result=do_tplink(ipAddress,offsw,9999)
		result=do_tplink(ipAddress,info,9999)
		printResult(result)
		time.sleep(5)
		result=do_tplink(ipAddress,onsw,9999)
		result=do_tplink(ipAddress,info,9999)
		printResult(result)
		return(None)
	else:
		print("Out door data last collected at:  weweex time: "+str(datetime.datetime.fromtimestamp(weweexTime)))

def main():

	global debug,rpig

	if platform.system().lower() == 'linux':
		rpig=rpiInitVariables("/home/pi/conf/siteconfig.json")
	else:
		rpig=rpiInitVariables("C:\\usr\\demo_projects\\pi\\hytta\\config.json")
	print()
	print("Reset OutDoor version: "+progVersion)
	print()
	resetOutDoor(rpig,'hytte_bod')



if __name__ == '__main__':
	main()