import sqlite3
import time
import platform
import json
import os
from rpiglobals import rpiInitVariables

#
# globals
#
debugFlagCommon=0
#
# Debug  
# debugFlagCommon == 2, debug print readDS1820json
# debugFlagCommon == 4, debug print getTempForGroup
#
def printDebugCommon(text):
	if (debugFlagCommon & 2)>0:
		print(text)
#
# verifyFileAge()
# 
# Verifies the age of the file, and if it is older than maxAgeInHours, return false
# 
#  Convert to int and compare to 3600 sek * maxAgeInHours
#
def verifyFileAge(fileName,maxAgeInHours):
	modTimesinceEpoc = int(os.path.getmtime(fileName))
	if int(time.time()) > modTimesinceEpoc + (maxAgeInHours*3600):
		return(False)
	return(True)   
#
#  Read DS1802 return lines
#
#  Verify Age of file,return False if to old
#  return False if any I/O error occurs
#
def readDS1820File(fileName,maxAgeInHours):
	try:
		if verifyFileAge(fileName,maxAgeInHours) is False:
			print('File: '+fileName+' is older than: '+str(maxAgeInHours)+' hours')
			return(False)
		f = open(fileName, 'r')
		lines = f.readlines()
		f.close()
		return lines
	except Exception as e:
		print('readDS1820File Error:')
		print(e)
		return(False)
#
#  readDS1820raw
#  Iterates maxLoops time to attempt to fetch value
#
def readDS1820raw(siteConfig,groupName,maxLoops,maxAgeInHours):

	loopCount=0
	lines=False
	parameterName=group['sensorconfig']
	fileName=siteConfig[parameterName]
	while   (loopCount<maxLoops):  # Need to loop in case we are just in a sensor read cycle
		if(not lines):        # Max loops
			time.sleep(0.2)
			lines = readDS1820File(fileName,maxAgeInHours)
			loopCount+=1
		elif lines[0].strip()[-3:] != 'YES': # File not ready
			time.sleep(0.2)
			lines = readDS1820File(fileName,maxAgeInHours)
			loopCount+=1
		else:
			break
			#
			# If loop ends with cloopCount=20 we did not succseed in readin the file
			#
	if(loopCount <maxLoops):
		equal_pos = lines[1].find('t=')
		if equal_pos != -1:
			temp_string = lines[1][equal_pos+2:]
			temp_c = float(temp_string) / 1000.0
			return(temp_c)
		else:
			print("getTempForGorup error: Group: "+group['groupName']+" wrong format in file")
			print(lines)
			return(False)
	else:
		print("getTempForGorup error: Group: "+group['groupName']+" File Read Error")
		return(False)

#
#  Read DS1802 in json format
# Assumes external script (getds1820V2.py) is run by crontab
#
def readDS1820json(siteConfig,group,maxAgeInHours):
	printDebugCommon('ds1820 debug')
	printDebugCommon(json.dumps(group))
	parameterName=group['sensorconfig']
	fileName=siteConfig[parameterName]
	printDebugCommon('Filename: '+fileName+' parameter Name: '+parameterName)
	#
	# Read the raw lines from file
	#
	lines = readDS1820File(fileName,maxAgeInHours)
	#
	# Parse JSON file
	#
	if lines is False:
		return(False)
	try:
		tempJson=json.loads(lines[0])
	except Exception as e:
		print('readDS1820json error:')
		print(e)
		return(False)
	return(tempJson)
#
#  Reading indoor temp from local Weewx sqlite database
#  inout 'indoor' or 'outdoor'
#
def readWeewx(siteConfig,group,inout):
		#
		# read from sqlite
		#
		conn = None
		#
		#  Set up a sqllite connection to a target
		#
		conn=create_connection(siteConfig[group['sensorconfig']])
		if conn is False:
			print("getTempForGroup error: Group: "+group['groupname']+" could not open sqllite db")
			return(False)  # Exit if connection fails
		#
		# Read the temp from the weewk db
		#		
		
		cur = conn.cursor()
		if inout == 'indoor':
			sqlstmt="select ifnull(inTemp,-99),datetime from archive  where datetime="
			sqlstmt=sqlstmt+"(select max(datetime) from archive)"
		elif inout == 'outdoor':
			sqlstmt="select ifnull(outTemp,-99),datetime from archive  where datetime="
			sqlstmt=sqlstmt+"(select max(datetime) from archive)"
		else: 
			print('Eror: readWeewx: inout paramter illeagl: '+str(inout))
			return(False)
		cur.execute(sqlstmt)
		rows = cur.fetchall()
		temp={}
		temp['temp']=((rows[0])[0]-32)/1.8
		temp['time']=rows[0][1]
		return(temp)


def create_connection(db_file):
	""" create a database connection to a SQLite database """
	conn = None
	try:
		conn = sqlite3.connect(db_file)
		# print(sqlite3.version)
	except Exception as sqliteError:
		print('sqllite open error:')
		print(sqliteError)
		return(False)
	return conn


#
# Fetches the temp for a given group, from the sensors, based on groupname, and metdot/file
# ds1820 type devices read temp from line 2 of a specific file, temp is coded without .
#
# weewx reads from sqlite db
#
#  Caller is responsible for veriyfing that group is active
#
#  Return fetched temp in a dict as follows['sensorname']['time']['temp']
#  If temp reading for som reason is not possible, return False
#
def getTempForGroup(siteConfig,group,maxFileAgeInHours):
	#
	# Local constants (to be moved to external config)
	#
	# Verify if inuse is set to Y
	#
	if(group['inuse'] != 'Y'):
		printDebugCommon("getTempForGorup error: Group: "+group['groupname']+" has not set inuse flag")
		return(False)
	#
	#  Split on sensor type
	#  ds1820 reads from a file
	#
	if group['sensortype'] == 'ds1820':
		# ds1820 type, read from file
		maxLoops=20
		return(readDS1820raw(siteConfig,group,maxLoops,maxFileAgeInHours))	
	elif group['sensortype'] == 'weewx':
		return(readWeewx(siteConfig,group,'indoor'))
	elif group['sensortype'] == 'weewx-outdoor':
		return(readWeewx(siteConfig,group,'outdoor'))
	elif group['sensortype'] == 'json':
		return(readDS1820json(siteConfig,group,maxFileAgeInHours))
	else:
		print("getTempForGorup error: Group: "+group['groupname']+" not imlemented")
		return(False)
	return(False)
#
# Loads site local configuration
#
# loads group memer configuration from file, assumes changes are rare
# if the file is not found, loads from iot service
#
def loadSiteConfig(siteConfigFile):
	
	#
	# Load master config file to get groupConfigFile path,
	# confURL, for static group membership
	# tempConfigURL for dynamic temp setting
	# groupconfig, contains statig gruop names and group sensor setup
	#
	allConfig={}
	siteConfig=rpiInitVariables(siteConfigFile)
	"""
	try:
		f=open(siteConfigFile,"r")
		strsiteconfig=f.read()
		siteConfig=json.loads(strsiteconfig)
		f.close()
	except IOError:
		print("Site Config File"+siteConfigFile+" is not accessible")
		return(False)
	"""
	tempSettingURL=siteConfig.config['tempSettingURL']
	groupConfigFileName=siteConfig.config['groupConfigFile']
	socketConfigFileName=siteConfig.config['socketConfigFile']
	#
	# Load static membership, 
	# if file exists, load local file
	# if not fetch form OT database
	#
	if os.path.isfile(groupConfigFileName):
		try:
			f=open(groupConfigFileName,"r")
			strconfig=f.read()
			groups=json.loads(strconfig)
			f.close()
		except IOError:
			print("Member Config File"+groupConfigFileName+" exists but is not accessible")
			return(False)
	else:
	# 
	# Group Config did not exists need to fetch it from iot database
	#
		groups=getGroups(siteConfig)
	#
	# Read the socket input file and add it to a dict
	# File is in host format  ip name
	# stored as an array  the config json
	allSockets=[]
	try:
		fp=open(socketConfigFileName)
		line=fp.readline().strip('\n')
		allSockets=[]
		while (line):
			pos=line.find(' ')
			ip=line[:pos]
			host=line[pos+1:].lstrip()
			sockets={}
			sockets['socketname']=host
			sockets['ip']=ip
			allSockets.append(sockets)
			line=fp.readline().strip('\n')
	except IOError:
		print("Socket Config File "+socketConfigFileName+" exists but is not accessible")
		return(False)
	#
	# build dics result
	#
	
	allConfig['groups']=groups
	allConfig['siteConfig']=siteConfig.config
	allConfig['tpSockets']=allSockets
	allConfig['rpig']=siteConfig
	return(allConfig)
