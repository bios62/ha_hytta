#!/bin/sh
#
sudo sh /home/pi/scripts/weewx.sh

