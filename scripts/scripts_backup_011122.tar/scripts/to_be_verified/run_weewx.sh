#!/bin/sh
uday=`date '+%u'`
SCRIPT=`basename $0 |cut -f 1 -d '.'`
CONFIGFILE=/home/pi/conf/siteconfig.json
LOGDIR=`cat $CONFIGFILE | jq '.logDirectory' | sed 's/"//g'`
LOGFILE=${LOGDIR}/${SCRIPT}_${uday}.log
echo date >>$LOGFILE
sudo sh /home/pi/scripts/weewx.sh >>$LOGFILE 2>&1
