from __future__ import print_function
import sys
import requests
import json
import urllib.parse
from struct import pack


version=2

def encrypt3(string):
	key = 171
	result = pack('>I', len(string))
	j=1
	for i in string:
		#a = key ^ ord(i)
		a = key ^ i
		key = a
		result+=bytes([a])
	return result

def decrypt3(string):
	key = 171
	result = "".encode('latin-1')
	for i in string:
		a = key ^ i
		key=i
		result += bytes([a])
	return result

def encrypt2(string):
	key = 171
	result = pack('>I', len(string))
	for i in string:
		a = key ^ ord(i)
		key = a
		result += chr(a)
	return result

def decrypt2(string):
	key = 171
	result = ""
	for i in string:
		a = key ^ ord(i)
		key = ord(i)
		result += chr(a)
	return result

def printascii(string):
	if type(string) is str:
		for c in string:
			print(ord(c),end=' ')
	else:
		for c in range(len(string)):
			print(string[c],end=' ')
	print()

def test1():
	print("Test start")
	if sys.version[0:3] == '2.7' :
		test='{"system":{"get_sysinfo":{}}}'
		print('version=2')
		eres=encrypt2(test)
		dres=decrypt2(eres)
	else:
		test='{"system":{"get_sysinfo":{}}}'.encode('latin-1')
		print('version=3')
		eres=encrypt3(test)
		dres=decrypt3(eres)
		print(type(eres))
	printascii(eres)
	#print(dres[4:])
	printascii(dres)

def saveProperty(siteid,propertyName,propertyValue):
	apiURL='http://revebaasen.no/php/savepropertyV3.php?'
	#headers = {"content-type": "application/json", "Authorization": "<auth-key>" }
	headers = {"content-type": "application/json"}
	payload={}
	payload['siteid']=siteid
	payload['propertyname']=propertyName
	payload['propertyvalue']=propertyValue
	apiURL+=urllib.parse.urlencode(payload)
	r = requests.get(apiURL, headers=headers)
	print(r)
	print(r.content)
#
# Actual test goes here
#
saveProperty('hytta','testvalx','17')
