import os
import glob
import time
import requests 
import urllib3
import sqlite3
import json
import platform
import urllib.parse
from sqlite3 import Error
from tplib3 import *
from rpiglobals import rpiInitVariables

# collector
#
# Collect all stats and updates iotlog table in desired cloud/database
# Collects, relays state of active relays, indoor temp in active zones, outdoor temp if available
##
# Python version: 3
#
# Modifictions
#   18/2  Something
#	5/8-20 added save of desired temp in main
#   28/11-20 Changed to use socket/device name only no prefix
#   29/12-20 Extended colelction to include out door temp if it is not NULL (None) in the database
#   31/10-21  Added SODA Support
# 
# Usage:
# python collector
#

progVersion="1.0 29122022"

if platform.system().lower() == 'linux':
	rpig=rpiInitVariables("/home/pi/conf/siteconfig.json")
else:
	rpig=rpiInitVariables("g:\\demo_projects\\pi\\hytta\\config.json")

#
# globals
#
debug=True

tplinkDevices={}


#
# Reads local temp from json file generated with externa scripts#

def read_ds1820(tempFile):
	fp=open(tempFile,"r")
	tempData=json.loads(fp.read())
	fp.close()
	return(tempData)
#
# NLU
#
def read_temp_rawx(rawtempfile):
	f = open(rawtempfile, 'r')
	lines = f.readlines()
	f.close()
	return lines
#
# NLU
#
def read_tempx(rawtempfile):
	lines = read_temp_raw(rawtempfile)
	temp_c=-50
	if len(lines) <= 1:
		return(-98)
	while lines[0].strip()[-3:] != 'YES':
		time.sleep(0.2)
		lines = read_temp_raw()
	equals_pos = lines[1].find('t=')
	if equals_pos != -1:
		temp_string = lines[1][equals_pos+2:]
		temp_c = float(temp_string) / 1000.0
		temp_f = temp_c * 9.0 / 5.0 + 32.0
	return temp_c
	

def create_connection(db_file):
	""" create a database connection to a SQLite database """
	conn = None
	try:
		conn = sqlite3.connect(db_file)
		# print(sqlite3.version)
	except Error as e:
		print(e)
	return conn

def gettemp_from_weewx(conn):
	"""
	Query all rows in the tasks table
	:param conn: the Connection object
	:return:
	"""
	cur = conn.cursor()
	sqlstmt="select inTemp,outTemp,datetime from archive  where datetime="
	sqlstmt=sqlstmt+"(select max(datetime) from archive)"
	cur.execute(sqlstmt)
	rows = cur.fetchall()
	result=dict()
	result['inDoor']=((rows[0])[0]-32)/1.8
	outTemp=(rows[0])[1]
	if(outTemp is None):
		result['outDoor']=None
	else:
		result['outDoor']=(outTemp-32)/1.8
	return(result)

def printResult(tempDevice,ipAddress,result):
	print("Device: "+tempDevice+" IP Address: "+ipAddress+" "+"Relay state: "+str(result["system"]["get_sysinfo"]["relay_state"]))

def getexternalip():
	
	# defining a params dict for the parameters to be sent to the API 
	#PARAMS = {'siteid':'=hytta','propertyname':'=ip'} 
	PARAMS='siteid=hytta'
	# sending get request and saving the response as response object 
	#r = requests.get(url = rpig.currentipURL, params = PARAMS,verify=False) 
	r = requests.get(url = rpig.currentipURL, params = PARAMS,verify=False) 
	if r :
		r.encoding='utf-8'
		return(r.text)
	# extracting data in json format 
	else:
		return('127.0.0.0')

def getexternalipV2(URL):
	#
	#  Fethc getmyip1URL
	#
	if debug:
		print('Fetching externap IP from: '+URL)
	urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)  # Disable SSL warnings
	headers = {"content-type": "application/json",'User-agent': 'Mozilla/5.0'}
	r = requests.get(url = URL,headers=headers,verify=False)
	if r :
		r.encoding='utf-8'
		return(r.text)
	else:
		return('1.1.1.2')

def getexternalip2_notused():
	#
	#  Fethc getmyip1URL
	#
	headers = {"content-type": "application/json",'User-agent': 'Mozilla/5.0'}
	r = requests.get(url = rpig.getmyip2URL,headers=headers,verify=False)
	print(r.text)
	if r :
		r.encoding='utf-8'
		print(r.text)
		return(r.text)
	else:
		
		return('2.2.2.3')



def collectDevice(socketfile):
# Read device IP addr
	fp=open(socketfile)
	line=fp.readline().strip('\n')
	info='{"system":{"get_sysinfo":{}}}'
# iterate through and verify temp
	results=dict()
	i=1
	while (line):
		if len(line) >1:
			ipAddress=line.split(' ')[0]
			tempDevice=line.split(' ')[1]
			tpState=do_tplink(ipAddress,info,9999,True)
			result=dict()
			result['device']=tempDevice
			result['ipaddress']=ipAddress
			result['relayState']=str(tpState["system"]["get_sysinfo"]["relay_state"])
			results[str(i)]=result
			i=i+1
		line=fp.readline().strip('\n')
	fp.close()
	return(results)


def collect(stats):
	#
	#
	#  Indor temp from DS1820, gang
	#    
	stats['gangpi']=read_ds1820(rpig.localtempfile)

	# Indor temp from DS1820, stue

	stats['stuepi']=read_ds1820(rpig.remotetempfile)

	# Indor temp Weewx, database

	conn = create_connection(rpig.weewxfile)
	stats['gangWeewx']='-99'
	with conn:
		weewxTemp=gettemp_from_weewx(conn)
		stats['gangWeewx']=weewxTemp['inDoor']
		stats['uteTemp']=weewxTemp['outDoor']		
	
	# State from plugs

	tpstates=collectDevice(rpig.socketConfigFile)
	stats['tpsockets']=tpstates
	# Get external IP
	#stats['ipaddressFromCloud']=json.loads(getexternalip())['currip']
	stats['ipaddressFromCloud1']=json.loads(getexternalipV2(rpig.getmyip1URL))['currentip']
	stats['ipaddressFromCloud2']=json.loads(getexternalipV2(rpig.getmyip2URL))['currentip']
	#print(stats['ipaddressFromCloud'])



def saveProperty(siteid,propertyName,propertyValue):

	# api-endpoint
	headers = {"content-type": "application/json"}
	#headers = {"content-type": "application/json", "Authorization": "<auth-key>" }
	payload={}
	payload['siteid']=siteid
	payload['logname']=propertyName
	payload['logvalue']=propertyValue
	apiURL=rpig.iotstatsURL[rpig.iotstatscloud]
	if rpig.iotstatscloud == "iosp" or rpig.iotstatscloud == "apex-evry" or rpig.iotstatscloud == "iosjump":	
		data=json.dumps(payload)
		r = requests.post(apiURL, headers=headers,data=data)
		if debug:
			print(apiURL)
			print(headers)
			print(data)
			print(r.status_code)
		if r.status_code > 201:
			#print(r.text)
			print(r.status_code)
	elif rpig.iotstatscloud == "one.com": 
		apiURL+=urllib.parse.urlencode(payload)
		r = requests.get(apiURL, headers=headers)
		if debug:
			print(r.status_code)
		if r.status_code > 200:
			print(r.text)
			print(r.status_code)
#
#  Save the data to a SODA structure in one REST call
# 			
def saveSoda(stats):
	headers = {"content-type": "application/json", "Authorization": "<auth-key>" }
	data=json.dumps(stats)
	r=requests.post(rpig.sodaURL,headers=headers,auth=(rpig.sodauser,rpig.sodapwd),data=data)
	print("SODA POST Status: "+str(r.status_code))

def main():

	global debug

	stats={}
	print()
	print("Stats collector version: "+progVersion)
	print()
	print("Saving properties to cloud: "+rpig.iotstatscloud)

	collect(stats)
	tempValues=stats['gangpi']
	tempstats=[]
	ipaddresses=[]
	sockets=[]
	#saveProperty('hytta','Pitemp-gang',"{:.2f}".format(tempValues['temp']))
	#saveProperty('hytta','Pitime-gang',tempValues['time'])
	#saveProperty('hytta','Pitemp-gang',tempValues['temp'])
	saveProperty('hytta','DS1820-gang',tempValues['time']+";"+tempValues['temp'])
	jvalue={}
	jvalue['name']='DS1820-gang'
	jvalue['value']=tempValues['time']+";"+tempValues['temp']
	tempstats.append(jvalue)
	tempValues=stats['stuepi']
	#saveProperty('hytta','Pitime-stue',tempValues['time']+";"+tempValues['temp'])
	#saveProperty('hytta','Pitemp-stue',tempValues['temp'])	
	saveProperty('hytta','DS1820-stue',tempValues['time']+";"+tempValues['temp'])
	jvalue={}
	jvalue['name']='DS1820-stue'
	jvalue['value']=tempValues['time']+";"+tempValues['temp']
	tempstats.append(jvalue)
	saveProperty('hytta','gangWeewx',"{:.2f}".format(stats['gangWeewx']))
	jvalue={}
	jvalue['name']='gangWeewx'
	jvalue['value']="{:.2f}".format(stats['gangWeewx'])
	tempstats.append(jvalue)
	jvalue={}
	if not( stats['uteTemp'] is None):
		saveProperty('hytta','uteTemp',"{:.2f}".format(stats['uteTemp']))
		jvalue={}
		jvalue['name']='uteTemp'
		jvalue['value']="{:.2f}".format(stats['uteTemp'])
		tempstats.append(jvalue)
	#saveProperty('hytta','ipaddressFromCloud',str(stats['ipaddressFromCloud']))
	saveProperty('hytta','ipaddressFromCloud1',str(stats['ipaddressFromCloud1']))
	jvalue={}
	jvalue['name']='ipaddressFromCloud1'
	jvalue['value']=str(stats['ipaddressFromCloud1'])
	ipaddresses.append(jvalue)
	saveProperty('hytta','ipaddressFromCloud2',str(stats['ipaddressFromCloud2']))
	jvalue={}
	jvalue['name']='ipaddressFromCloud2'
	jvalue['value']=str(stats['ipaddressFromCloud2'])
	ipaddresses.append(jvalue)
	#print(json.dumps(stats['tpsockets']))
	for i in stats['tpsockets']:
		if stats['tpsockets'][i]['relayState']  == "0":
			rState='OFF'
		else:
			rState='ON'
		#saveProperty('hytta',"tpsocket_"+stats['tpsockets'][i]['device'],rState)
		saveProperty('hytta',stats['tpsockets'][i]['device'],rState)
		jvalue={}
		jvalue['devicename']=stats['tpsockets'][i]['device']
		jvalue['ipaddress']=stats['tpsockets'][i]['ipaddress']
		jvalue['relayState']=rState
		sockets.append(jvalue)
	#
	#  Upload to SODA API
	#
	jstat={}
	jstat['sitename']='hytta'
	jstat['temp']=tempstats
	jstat['ipaddresses']=ipaddresses
	jstat['tpsockets']=sockets
	print(json.dumps(jstat))
	saveSoda(jstat)
if __name__ == '__main__':
	main()
	#stats={}
	#stats["test1"]="15"
	#stats["test2"]=25
	#saveSoda(stats)
