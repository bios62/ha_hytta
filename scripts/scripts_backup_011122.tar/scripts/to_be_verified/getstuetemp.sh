#!/bin/bash
export LOGFILE=/home/pi/logs/getstuetemp.log
DATO=`date`
echo "# Stuetemp fetched: " $DATO >>$LOGFILE
sshpass -p 'mercedes450sl' ssh pi@192.168.0.129 "cat /sys/devices/w1_bus_master1/28-01144a1e45aa/w1_slave">/home/pi/variables/stue-temp
cat /home/pi/variables/stue-temp | grep 't='  >>$LOGFILE
