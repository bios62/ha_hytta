#!/bin/bash
source $HOME/tplink_env/bin/activate
cd $HOME/python-scripts
export IP=`cat $HOME/scripts/IPADDR`
if [ $# -ne 2 ]
then
  echo "usage: tpswitch place on|off|status"
fi
if [ "$1" = "gang" ] 
then
  if [ "$2" = "on" ]
  then
    RELAY='{"system":{"set_relay_state":{"state":1}}}'
  elif [ "$2" = "off" ]
  then 
    RELAY='{"system":{"set_relay_state":{"state":0}}}'
  elif [ "$2" = "status" ]
  then 
    RELAY=''
  else
   echo "Ulovlig funksjon, gyldig verdi er on|off|status"
   exit 1
  fi
  if [ "$RELAY" != "" ]
  then
    python tplink.py -t $IP -j $RELAY
  fi
  python tplink.py -t $IP -c info 
else
  echo "ukjent plassering"
  exit 1
fi
exit 0
