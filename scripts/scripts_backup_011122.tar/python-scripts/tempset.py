#import os
#import glob
#import time
import requests 
#import sqlite3
import json
#import urllib.parse
#from sqlite3 import Error
#from tplib3 import *

progVersion="1.14032020"
memberURL="https://tn1tv18ynzxubz5-iosp.adb.eu-frankfurt-1.oraclecloudapps.com/ords/iot/iotv1/groups/"

#
# Fetch memer structure from Autonomous DB
#
def getMembers(URL):
    headers = {"content-type": "application/json"}
    r = requests.get(url = URL, headers=headers)
    if (r.ok):
        #
        # Got data from autonomous
        #
        members=json.loads(r.text)
        print(len(members['items']))
#
#  Main 
# define version, set p
#
# Retrieves from autonomous database current group setup
# Filters group members and set temp fro groups
#
# 
def main():
	stats={}
	print("Termostat version: "+progVersion)
	getMembers(memberURL)

if __name__ == '__main__':
	main()