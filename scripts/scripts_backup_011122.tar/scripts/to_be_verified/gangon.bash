#!/bin/sh
bash tplink
