#
# termstatus.py
#   
#
# Program that reads the 3 temp sources, weexw, local DS1820 and remote DS1820, with new local files
#
# TODO: Add list of socket memers state pr. group
# 
#
##
# Python version: -2.7 due  tplib
#
# Modifictions
#   6/8-2020  Added new style of getting desired temp from groups
#   4/8-2020  Changed to use rpiglobals for all settings
#   4/8-2020  Changed to use files copied by cronscript with jsonformat for ds1820 remote and local
# 
# Usage:
# python termstatus [--zone  sone list, comma separated] [--configfile  siteconfig]

"""
Imports
"""

import sqlite3
from sqlite3 import Error
from tplib import *
import datetime
import platform
from rpiglobals import rpiInitVariables

"""
Globals
"""
outdoorTemp=-50
if platform.system().lower() == 'linux':
	defaultConfigFile="/home/pi/conf/siteconfig.json"
else:
	defaultConfigFile="C:\\usr\\demo_projects\\pi\\hytta\\config.json"
progVersion="1.101219"


#
# Creates connection to local sqllite file fro fetch of weewx data
#
# dbfile name passes as parameter, derived from prig by calling method
#
def create_connection(db_file):
	""" create a database connection to a SQLite database """
	conn = None
	try:
		conn = sqlite3.connect(db_file)
	except Error as e:
		print(e)
	return conn

def gettemp_from_weewx(conn):
	"""
	Query all rows in the tasks table
	:param conn: the Connection object
	:return:
	"""
	global outdoorTemp
	outdoorTemp=(-50)
	cur = conn.cursor()
	sqlstmt="select inTemp,ifnull(outTemp,-22),datetime from archive  where datetime="
	sqlstmt=sqlstmt+"(select max(datetime) from archive)"
	cur.execute(sqlstmt)
 
	rows = cur.fetchall()
#        print (type(rows[0]))
 
#	for row in rows:
#		print(row)
	inTemp=((rows[0])[0]-32)/1.8
	if(((rows[0])[1]) != -22):
		outdoorTemp=((rows[0])[1]-32)/1.8
	else:
		outdoorTemp=-60
	return(inTemp)
#
# Read local copies of ds1820
# based on filename
#
def read_ds1820(tempFile):
	fp=open(tempFile,"r")
	tempData=json.loads(fp.read())
	fp.close()
	return(tempData)
#
# 
#
def readSocketFile(filename):
	try:
		lines=[]
		fp=open(filename,"r")
		line=fp.readline().strip('\n')
		while (line):
			lines.append(line)
			line=fp.readline().strip('\n')
		fp.close()
		return(lines)
	except Exception as e:
		print(e)
		return(false)
#
# 
#
def readConfigFile(filename):
	try:
		lines=[]
		fp=open(filename,"r")
		dt=json.loads(fp.read())
		fp.close()
		return(dt)
	except Exception as e:
		print(e)
		return(false)

def printResult(tempDevice,ipAddress,result):
	
#    for line in result:
#        if(line.find("alias")>=0 or line.find("relay_state")>=0 or line.find("err_code")>=0):
#            print(line)

	#print(result)
	print("Device: "+tempDevice+" IP Address: "+ipAddress+" "+"Relay state: "+str(result["system"]["get_sysinfo"]["relay_state"]))

	
def main():
	
	global outdoorTemp
	

	onsw='{"system":{"set_relay_state":{"state":1}}}'
	offsw= '{"system":{"set_relay_state":{"state":0}}}'
	info='{"system":{"get_sysinfo":{}}}'
	
	argsParser=argparse.ArgumentParser(description='Temperature and device status')
	argsParser.add_argument("--zone",default="gang,stue",type=str,help="Comma separated list of zones gang,stue")
	argsParser.add_argument("--configfile",default=defaultConfigFile,type=str,help="Filnavn med desired temp for sone")
	args=argsParser.parse_args()
	rpig=rpiInitVariables(args.configfile)

	print("  Temp Status version: "+progVersion+" "+datetime.datetime.now().strftime("%d/%m-%Y %H:%M:%S"))

	#
	# get list of zones tp process
	# 
	zones= args.zone.split(',')
	#
	# Read all config files
	#
	sockets=readSocketFile(rpig.socketConfigFile)
	tempSettings=readConfigFile(rpig.desiredtempfile)
	groupSettings=readConfigFile(rpig.groupConfigFile)
	# iterate through and verify temp
		 
	for zone in list (zones):
		#
		# Find temp settngs for the zone
		#
		print("Status values for zone: "+zone)
		currtempSetting=None
		for  i in range(0,len(tempSettings)):
			if tempSettings[i]['groupname'].lower() == zone.lower():
				currtempSetting=tempSettings[i]
				break
		if currtempSetting is None:   # Zone not found Akward
			destTemp=-5
		else:
			if currtempSetting['selectedtemp'] == 'L':
				destTemp=currtempSetting['lowtemp']
			else:
				destTemp=currtempSetting['hightemp']
		if zone =='gang':
		# create a database connection
			database = rpig.weewxfile
			conn = create_connection(database)
			currTemp=gettemp_from_weewx(conn)
		# Read desired temp
			print("  Outdoor temp: "+str(outdoorTemp)+" Indoor temp: "+str(currTemp)+" Desired indoor temp: "+str(destTemp))
		if zone == 'stue':
			currTemp=read_ds1820(rpig.remotetempfile)
			print("   Indoor temp: "+currTemp['temp']+" recorded at: "+currTemp['time']+" Desired indoor temp: "+str(destTemp))
		#
		# Iterate over socket lines to find socket in group
		#
		# Find correct group
		for  groupSetting in (list(groupSettings)):
			if groupSetting['groupname'].lower() == zone.lower():
				socketList=groupSetting['members']
				break
		#
		# Find socket state
		#
		for socket in (list(socketList)):
			for line in list(sockets):
				if line.find(socket)>0:
					ipAddress=line.split(' ')[0]
					tempDevice=line.split(' ')[1]
					print(ipAddress+" "+tempDevice)
					result=do_tplink(ipAddress,info,9999,True)
					printResult(tempDevice,ipAddress,result)
		print("temp scan complete")


if __name__ == '__main__':
	main()
