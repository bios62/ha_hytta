import sqlite3
import time
import platform
import json
import os
#
# verifyFileAge()
# 
# Verifies the age of the file, and if it is older than maxAgeInHours, return false
# 
#  Convert to int and compare to 3600 sek * maxAgeInHours
#
def verifyFileAge(fileName,maxAgeInHours):
	modTimesinceEpoc = int(os.path.getmtime(fileName))
	if int(time.time()) > modTimesinceEpoc + (maxAgeInHours*3600):
		return(False)
	return(True)   
#
#  Read DS1802 return lines
#
#  Verify Age of file,return False if to old
#  return False if any I/O error occurs
#
def readDS1820File(fileName,maxAgeInHours):
	try:
		if verifyFileAge(fileName,maxAgeInHours) is False:
			print('File: '+fileName+' is older than: '+str(maxAgeInHours)+' hours')
			return(False)
		f = open(fileName, 'r')
		lines = f.readlines()
		f.close()
		return lines
	except Exception as e:
		print('readDS1820File Error:')
		print(e)
		return(False)
#
#  readDS1820raw
#  Iterates maxLoops time to attempt to fetch value
#
def readDS1820raw(siteConfig,groupName,maxLoops,maxAgeInHours):

	loopCount=0
	lines=False
	parameterName=group['sensorconfig']
	fileName=siteConfig[parameterName]
	while   (loopCount<maxLoops):  # Need to loop in case we are just in a sensor read cycle
		if(not lines):        # Max loops
			time.sleep(0.2)
			lines = readDS1820File(fileName,maxAgeInHours)
			loopCount+=1
		elif lines[0].strip()[-3:] != 'YES': # File not ready
			time.sleep(0.2)
			lines = readDS1820File(fileName,maxAgeInHours)
			loopCount+=1
		else:
			break
			#
			# If loop ends with cloopCount=20 we did not succseed in readin the file
			#
	if(loopCount <maxLoops):
		equal_pos = lines[1].find('t=')
		if equal_pos != -1:
			temp_string = lines[1][equal_pos+2:]
			temp_c = float(temp_string) / 1000.0
			return(temp_c)
		else:
			print("getTempForGorup error: Group: "+group['groupName']+" wrong format in file")
			print(lines)
			return(False)
	else:
		print("getTempForGorup error: Group: "+group['groupName']+" File Read Error")
		return(False)

#
#  Read DS1802 in json format
# 
#
def readDS1820json(siteConfig,group,maxAgeInHours):
	parameterName=group['sensorconfig']
	fileName=siteConfig[parameterName]
	#
	# Read the raw lines from file
	#
	lines = readDS1820File(fileName,maxAgeInHours)
	#
	# Parse JSON file
	#
	if lines is False:
		return(False)
	try:
		tempJson=json.loads(lines[0])
	except Exception as e:
		print('readDS1820json error:')
		print(e)
		return(False)
	#
	# Verify if Json structure is correct
	#
	if 'temp' in tempJson:
		return(float(tempJson['temp']))
#
#  Reading indoor temp from local Weewx sqlite database
#
def readWeewx(group):
		#
		# read from sqlite
		#
		conn = None
		#
		#  Set up a sqllite connection to a target
		#
		try:
			conn = sqlite3.connect(siteConfig[group['sensorconfig']])
		except Error as e:
			print(e)
			print("getTempForGorup error: Group: "+group['groupName']+" could not open sqllite db")
			return(False)  # Exit if connection fails
		#
		# Read the temp from the weewk db
		#		
		outdoorTemp=False
		cur = conn.cursor()
		sqlstmt="select inTemp,ifnull(outTemp,-22),datetime from archive  where datetime="
		sqlstmt=sqlstmt+"(select max(datetime) from archive)"
		cur.execute(sqlstmt)
		rows = cur.fetchall()
		inTemp=((rows[0])[0]-32)/1.8
		return(inTemp)

#
# Fetches the temp for a given group, from the sensors, based on groupname, and metdot/file
# ds1820 type devices read temp from line 2 of a specific file, temp is coded without .
#
# weewx reads from sqlite db
#
#  Caller is responsible for veriyfing that group is active
#
#  Return fetched temp
#  If temp reading for som reason is not possible, return False
#
def getTempForGroup(allConfig,group,maxFileAgeInHours):
	#
	# Local constants (to be moved to external config)
	#
	# Verify if inuse is set to Y
	#
	if(group['inuse'] != 'Y'):
		print("getTempForGorup error: Group: "+group['groupname']+" has not set inuse flag")
		return(False)
	#
	#  Split on sensor type
	#  ds1820 reads from a file
	#
	if group['sensortype'] == 'ds1820':
		# ds1820 type, read from file
		maxLoops=20
		return(readDS1820raw(allConfig['siteConfig'],group,maxLoops,maxFileAgeInHours))	
	elif group['sensortype'] == 'weewx':
		return(readWeewx(group))
	elif group['sensortype'] == 'json':
		return(readDS1820json(allConfig['siteConfig'],group,maxFileAgeInHours))
	else:
		print("getTempForGorup error: Group: "+group['groupname']+" not imlemented")
		return(False)
	return(False)