import json
#
#  Changelog
#  5/8-20  Changed 
#  27/7-22  Changed to protect with try/except
#
# 14/8, intorduced iotDirectory to avoid file path hardcoding
#
class rpiInitVariables:
	def __init__ (self,configFileName):
		fp=open(configFileName,"r")
		params=json.loads(fp.read())
		fp.close()
		self.config={}    # Json representation
		try:
			self.weewxfile=params['weewxfile']
		except KeyError:
			self.weewxfile=params['weewxfile']='undefined'
		self.config['weewxfile']=params['weewxfile']
		try:
			self.desiredtempfile=params['desiredtempfile']
		except KeyError:
			self.desiredtempfile=params['desiredtempfile']='undefined'
		self.config['desiredtempfile']=params['desiredtempfile']
		try:
			self.remotetempfile=params['remotetempfile']
		except KeyError:
			self.remotetempfile=params['remotetempfile']='undefined'
		self.config['remotetempfile']=params['remotetempfile']
		try:
			self.localtempfile=params['localtempfile']
		except KeyError:
			self.localtempfile=params['localtempfile']='undefined'
		self.config['localtempfile']=params['localtempfile']
		try:
			self.iotstatscloud=params['iotstatscloud']
		except KeyError:
			self.iotstatscloud=params['iotstatscloud']='undefined'
		self.config['iotstatscloud']=params['iotstatscloud']
		try:
			self.iotstatsURL=params['iotstatsURL']
		except KeyError:
			self.iotstatsURL=params['iotstatsURL']='undefined'
		self.config['iotstatsURL']=params['iotstatsURL']			
		try:
			self.socketConfigFile=params['socketConfigFile']
		except KeyError:
			self.socketConfigFile=params['socketConfigFile']='undefined'
		self.config['socketConfigFile']=params['socketConfigFile']
		try:
			self.membersURL=params['membersURL']
		except KeyError:
			self.membersURL=params['membersURL']='undefined'
		self.config['socketConfigFile']=params['socketConfigFile']
		try:
			self.groupConfigURL=params['groupConfigURL']
		except KeyError:
			self.groupConfigURL=params['groupConfigURL']='undefined'
		self.config['groupConfigURL']=params['groupConfigURL']
		try:
			self.tempSettingURL=params['tempSettingURL']
		except KeyError:
			self.tempSettingURL=params['tempSettingURL']='undefined'
		self.config['tempSettingURL']=params['tempSettingURL']
		try:
			self.iotlogurl=params['iotlogurl']
		except KeyError:
			self.iotlogurl=params['iotlogurl']='undefined'
		self.config['iotlogurl']=params['iotlogurl']
		try:
			self.groupConfigFile=params['groupConfigFile']
		except KeyError:
			self.groupConfigFile=params['groupConfigFile']='undefined'
		self.config['groupConfigFile']=params['groupConfigFile']
		try:
			self.currentipURL = params['currentipURL']
		except KeyError:
			self.currentipURL = params['currentipURL']='undefined'
		self.config['currentipURL']=params['currentipURL']
		try:
			self.getmyip1URL = params['getmyip1URL']
		except KeyError:
			self.getmyip1URL = params['getmyip1URL']='undefined'
		self.config['getmyip1URL']=params['getmyip1URL']
		try:
			self.getmyip2URL = params['getmyip2URL']
		except KeyError:
			self.getmyip2URL = params['getmyip2URL']='undefined'
		self.config['getmyip2URL']=params['getmyip2URL']
		try:
			self.sodauser = params['sodauser']
		except KeyError:
			self.sodauser = params['sodauser']='undefined'
		self.config['sodauser']=params['sodauser']
		try:
			self.sodapwd = params['sodapwd']
		except KeyError:
			self.sodapwd = params['sodapwd']='undefined'
		self.config['sodapwd']=params['sodapwd']
		try:
			self.sodaURL = params['sodaURL']
		except KeyError:
			self.sodaURL = params['sodaURL']='undefined'
		self.config['sodaURL']=params['sodaURL']
		try:
			self.iotDirectory = params['iotDirectory']
		except KeyError:
			self.iotDirectory = params['iotDirectory']='undefined'
		self.config['iotDirectory']=params['iotDirectory']
		try:
			self.iotDirectory = params['maxAgeInHours']
		except KeyError:
			self.iotDirectory = params['maxAgeInHours']='undefined'
		self.config['maxAgeInHours']=params['maxAgeInHours']
