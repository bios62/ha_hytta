#!/bin/bash
#
# Updated: 22/8-2022
#
# Scans all devices and updates IP adresses of connected TPLINK devices
#
uday=`date '+%u'`
SCRIPT=`basename $0 |cut -f 1 -d '.'`
LOGDIR=`cat /home/pi/conf/siteconfig.json | jq '.logDirectory' | sed 's/"//g'`
LOGFILE=${LOGDIR}/${SCRIPT}_${uday}.log
RESULTFILE=${LOGDIR}/tpsockets.tmp
SOCKETCONFIGFILE=`cat /home/pi/conf/siteconfig.json | jq '.socketConfigFile' | sed 's/"//g'`
source $HOME/tplink_env/bin/activate
cd $HOME/python-scripts
DATO=`date`
echo "# Updated: " $DATO >>$LOGFILE
python2 /home/pi/python-scripts/tpscan.py --subnet 192.168.0.1 --ipstart 130 --ipend 145 --tpport 9999 --resultfile $RESULTFILE >>$LOGFILE
# 
# Need some sanity check
#
mv $RESULTFILE $SOCKETCONFIGFILE
