import os
import glob
import time
import requests 
import urllib3
import sqlite3
import json
import platform
import urllib.parse
from sqlite3 import Error
from tplib3 import *
from rpiglobals import rpiInitVariables
from commonV1 import *
import argparse

# collector
#
# Collect all stats and updates iotlog table in desired cloud/database
# Collects, relays state of active relays, indoor temp in active zones, outdoor temp if available
##
# Python version: 3
#
# Modifictions
#   18/2  Something
#	5/8-20 added save of desired temp in main
#   28/11-20 Changed to use socket/device name only no prefix
#   29/12-20 Extended colelction to include out door temp if it is not NULL (None) in the database
#   31/10-21  Added SODA Support
#   2/10-22  Made colelction more robust, swith to use sensorlib.py
# Usage:
# python collector
#

progVersion="2.0 071022"

#
# globals
#
#debug=True
#defaultDebugFlag=2+4+8+16+32
#defaultDebugFlag=127
defaultDebugFlag=0
global debugFlag
rpig=None

tplinkDevices={}

def printResult(tempDevice,ipAddress,result):
	print("Device: "+tempDevice+" IP Address: "+ipAddress+" "+"Relay state: "+str(result["system"]["get_sysinfo"]["relay_state"]))

DBG0 =0b00000000
DBG1 =0b00000001
DBG2 =0b00000010
DBG4 =0b00000100
DBG8 =0b00001000
DBG16=0b00010000
DBG32=0b00100000
DBG64=0b01000000
#
# Debug  
# debugFlag == 2, debug gettemp operations
# debugFlag == 4, debug texternalipV2
# debugFlag == 8, debug main
# debugFlag == 16  saveSoda
# debugflag == 32 saveProperty
#
def printDebug(text,dbg):
	global debugFlag
	if (debugFlag&dbg)>0:
		print(text)


def getexternalip_NLU():
	
	# defining a params dict for the parameters to be sent to the API 
	#PARAMS = {'siteid':'=hytta','propertyname':'=ip'} 
	PARAMS='siteid=hytta'
	# sending get request and saving the response as response object 
	#r = requests.get(url = rpig.currentipURL, params = PARAMS,verify=False) 
	r = requests.get(url = rpig.currentipURL, params = PARAMS,verify=False) 
	if r :
		r.encoding='utf-8'
		return(r.text)
	# extracting data in json format 
	else:
		return('127.0.0.0')

def getexternalipV2(URL):
	#
	#  Fethc getmyip1URL
	#
	printDebug('Fetching externap IP from: '+URL,DBG4)
	urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)  # Disable SSL warnings
	headers = {"content-type": "application/json",'User-agent': 'Mozilla/5.0'}
	r=False
	try:
		r = requests.get(url = URL,headers=headers,verify=False)
	except Exception as httpError:
		print('Error when fetching external IP (getexternalipV2):')
		print(httpError)
		r=False
	#
	# Evaluate result
	#
	if r :
		r.encoding='utf-8'
		return(r.text)
	else:
		#
		# Clearly mark the IP as undefined
		#
		return(False)
#
#  Read the scoket config file
#  Iterate through all sockets and  fetch relay state
#  Externa script updates the socket config file with relay state
#
def collectDevice(socketfile):
# Read device IP addr
	fp=open(socketfile)
	line=fp.readline().strip('\n')
	info='{"system":{"get_sysinfo":{}}}'
# iterate through and verify temp
	results=dict()
	i=1
	while (line):
		if len(line) >1:
			ipAddress=line.split(' ')[0]
			tempDevice=line.split(' ')[1]
			tpState=do_tplink(ipAddress,info,9999,True)
			result=dict()
			result['device']=tempDevice
			result['ipaddress']=ipAddress
			result['relayState']=str(tpState["system"]["get_sysinfo"]["relay_state"])
			results[str(i)]=result
			i=i+1
		line=fp.readline().strip('\n')
	fp.close()
	return(results)


def collect(allConfig,stats):
	#
	# Globals
	#
	global rpig
	#  Indor temp from DS1820, gang
	# 
	# 
	tempStats={}
	
	for member in list(allConfig['groups']): 
		if member['inuse'] == 'Y':
			printDebug('processing temp group: '+member['groupname'],DBG64)
			currentTemp=getTempForGroup(allConfig['siteConfig'],member,int(allConfig['siteConfig']['maxAgeInHours']))
			if not (currentTemp == False):
				tempStats[member['groupname']]=currentTemp
				printDebug('Grop: '+member['groupname']+json.dumps(tempStats[member['groupname']]),DBG64)
			else:
				printDebug('Grop: '+member['groupname']+' temp is False',DBG64)
	stats['tempStats']=tempStats
	#
	# Collect socket status
	#
	tpstates=collectDevice(allConfig['siteConfig']['socketConfigFile'])
	stats['tpsockets']=tpstates
	#
	# Get external IP
	#
	ipStats={}
	try:
		ipStats['ipaddressFromCloud1']=json.loads(getexternalipV2(rpig.getmyip1URL))
	except:
		ipStats['ipaddressFromCloud1']=json.loads('{"currip":"1.1.1.1"}')  # Somethin went wrong....
	try:
		ipStats['ipaddressFromCloud2']=json.loads(getexternalipV2(rpig.getmyip2URL))
	except:
		ipStats['ipaddressFromCloud2']=json.loads('{"currip":"1.1.1.1"}')  # Somethin went wrong..
	stats['ipStats']=ipStats

def saveProperty(siteid,propertyName,propertyValue):
	#
	# Globals
	#
	global rpig
	#
	# Saving to endpoint
	#
	# api-endpoint
	headers = {"content-type": "application/json"}
	#headers = {"content-type": "application/json", "Authorization": "<auth-key>" }
	payload={}
	payload['siteid']=siteid
	payload['logname']=propertyName
	payload['logvalue']=propertyValue
	apiURL=rpig.iotstatsURL
	if rpig.iotstatscloud == "iosp" or rpig.iotstatscloud == "apex-evry" or rpig.iotstatscloud == "iosjump":	
		data=json.dumps(payload)
		r = requests.post(apiURL, headers=headers,data=data)
		printDebug(apiURL,DBG32)
		printDebug(headers,DBG32)
		printDebug(data,DBG32)
		printDebug(r.status_code,DBG32)
		if r.status_code > 201:
			print(r.status_code)
		else:
			printDebug('Sucessfully saved property: '+str(r.status_code),DBG32)
			print('Sucessfully saved property: '+propertyName+' value: '+propertyValue+' http Status: '+str(r.status_code))
	elif rpig.iotstatscloud == "one.com": 
		apiURL+=urllib.parse.urlencode(payload)
		r = requests.get(apiURL, headers=headers)
		printDebug(r.status_code,DBG32)
		if r.status_code > 200:
			print(r.text)
			print(r.status_code)
#
#  Save the data to a SODA structure in one REST call
# 			
def saveSoda(stats):
	headers = {"content-type": "application/json", "Authorization": "<auth-key>" }
	data=json.dumps(stats)
	r=requests.post(rpig.sodaURL,headers=headers,auth=(rpig.sodauser,rpig.sodapwd),data=data)
	printDebug(r.status_code,DBG16)
	if r.status_code > 201:
			print(r.text)
			print(r.status_code)
	else:
		print("SODA POST Success: ")
		print(str(r.text))

def main():

	global debugFlag
	global rpig

	stats={}
	print()
	print("Stats collector version: "+progVersion)
	#
	# Get site config
	#
	if platform.system().lower() == 'linux':
		siteConfigFile="/home/pi/conf/siteconfig.json"
	else:
		siteConfigFile="g:\\demo_projects\\pi\\hytta\\config.json"

	argsParser=argparse.ArgumentParser(description='Collector program')
	argsParser.add_argument("--configfile",default=siteConfigFile,type=str,help="Site Config File")
	argsParser.add_argument("--debug",default=0,type=int,help="debug flag")
	args=argsParser.parse_args()
	siteConfigFile=args.configfile
	if args.debug == 0:
		debugFlag=defaultDebugFlag
	else:
		debugFlag=args.debug
	print("Debug:"+str(debugFlag))
	#
	#  Load config
	#
	allConfig=loadSiteConfig(siteConfigFile)
	rpig=allConfig['rpig']
	#
	# Print save URL
	#
	print()
	print("Saving properties to cloud: "+allConfig['siteConfig']['iotstatscloud'])
	collect(allConfig,stats)
	printDebug('resultat: ',DBG8)
	printDebug(json.dumps(stats),DBG8)
	#
	# Current we have collected the follwing stats
	#
	#  Ipadress from two soruces
	#  temp from applicable sources
	#  tp sockets
	#  collected in the dictionary stats['tempStats'],['ipStats'],['tpsockets']
	#
	# process tempStats
	#
	jsonStats=[]
	printDebug(json.dumps(stats['tempStats']),DBG8)
	for sensorName in list(stats['tempStats']):
		tempValues=stats['tempStats'][sensorName]
		if not (stats['tempStats'][sensorName] == False):
			saveProperty('hytta',sensorName,tempValues['time']+";"+str(tempValues['temp']))
			printDebug('name: '+sensorName+' time: '+tempValues['time']+' value: '+str(tempValues['temp']),DBG8)
		else:
			printDebug('name: '+sensorName+ 'is False',DBG8)

	for ipName in list(stats['ipStats']):
		ipValues=stats['ipStats'][ipName]
		printDebug('name: '+ipName+' '+'currip: '+ipValues['currip'],DBG8)
		saveProperty('hytta',ipName,ipValues['currip'])

	for deviceName in list(stats['tpsockets']):
		device=stats['tpsockets'][deviceName]
		printDebug('name: '+device['device']+' ipaddress: '+device['ipaddress']+' State: '+device['relayState'],DBG8)
		saveProperty('hytta',device['device'],('ON 'if device['relayState']== 0 else 'OFF'))

	#
	#  Upload to SODA API
	#  Basically copy everything, but coded in case a more selective upload is needed
	#
	jStats={}
	jStats['sitename']='hytta'
	jStats['temp']=stats['tempStats']
	jStats['ipaddresses']=stats['ipStats']
	jStats['tpsockets']=stats['tpsockets']
	saveSoda(jStats)
	printDebug('*********************',DBG8)
	printDebug(json.dumps(stats),DBG8)
	printDebug('*********************',DBG8)
	
if __name__ == '__main__':
	main()
	#stats={}
	#stats["test1"]="15"
	#stats["test2"]=25
	#saveSoda(stats)
